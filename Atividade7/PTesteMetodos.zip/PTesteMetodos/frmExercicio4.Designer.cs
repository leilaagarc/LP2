﻿
namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTexto = new System.Windows.Forms.RichTextBox();
            this.btnQtdnumero = new System.Windows.Forms.Button();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnQtdletras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(296, 55);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(161, 186);
            this.txtTexto.TabIndex = 0;
            this.txtTexto.Text = "";
            // 
            // btnQtdnumero
            // 
            this.btnQtdnumero.BackColor = System.Drawing.Color.MediumOrchid;
            this.btnQtdnumero.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdnumero.ForeColor = System.Drawing.SystemColors.Control;
            this.btnQtdnumero.Location = new System.Drawing.Point(503, 55);
            this.btnQtdnumero.Name = "btnQtdnumero";
            this.btnQtdnumero.Size = new System.Drawing.Size(149, 47);
            this.btnQtdnumero.TabIndex = 1;
            this.btnQtdnumero.Text = "Quantidade de caracteres numéricos";
            this.btnQtdnumero.UseVisualStyleBackColor = false;
            this.btnQtdnumero.Click += new System.EventHandler(this.btnQtdnumero_Click);
            // 
            // btnBranco
            // 
            this.btnBranco.BackColor = System.Drawing.Color.MediumOrchid;
            this.btnBranco.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranco.ForeColor = System.Drawing.SystemColors.Control;
            this.btnBranco.Location = new System.Drawing.Point(503, 120);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(149, 54);
            this.btnBranco.TabIndex = 2;
            this.btnBranco.Text = "Posição do primeiro caracter branco\r\n";
            this.btnBranco.UseVisualStyleBackColor = false;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnQtdletras
            // 
            this.btnQtdletras.BackColor = System.Drawing.Color.MediumOrchid;
            this.btnQtdletras.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdletras.ForeColor = System.Drawing.SystemColors.Control;
            this.btnQtdletras.Location = new System.Drawing.Point(503, 195);
            this.btnQtdletras.Name = "btnQtdletras";
            this.btnQtdletras.Size = new System.Drawing.Size(149, 46);
            this.btnQtdletras.TabIndex = 3;
            this.btnQtdletras.Text = "Quantidade de caracteres alfabéticos";
            this.btnQtdletras.UseVisualStyleBackColor = false;
            this.btnQtdletras.Click += new System.EventHandler(this.btnQtdletras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PTesteMetodos.Properties.Resources.Lilac_Solid_100__Cotton_Fabric;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnQtdletras);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.btnQtdnumero);
            this.Controls.Add(this.txtTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtTexto;
        private System.Windows.Forms.Button btnQtdnumero;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnQtdletras;
    }
}