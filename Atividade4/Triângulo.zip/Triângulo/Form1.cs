﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triângulo
{
    public partial class Triângulo : Form
    {
        Double ladoA;
        Double ladoB;
        Double ladoC;
        public static string nome;
        public Triângulo()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtResultado.Clear();

            txtA.Focus();
        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            if(Double.TryParse(txtA.Text, out ladoA) 
                && Double.TryParse(txtB.Text, out ladoB) 
                && Double.TryParse(txtC.Text, out ladoC))
            {
                if ((Math.Abs(ladoB - ladoC) < ladoA && ladoA < ladoB + ladoC)
                    && (Math.Abs(ladoA - ladoC) < ladoB && ladoB < ladoA + ladoC)
                    && (Math.Abs(ladoA - ladoB) < ladoC && ladoC < ladoA + ladoB))
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                        txtResultado.Text = "O triângulo é equilátero!";
                    else if (ladoA != ladoB && ladoA != ladoC && ladoB != ladoC)
                        txtResultado.Text = "O triângulo é escaleno!";
                    else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                        txtResultado.Text = "O triângulo é isóceles!";
                }
                else 
                    MessageBox.Show("Valores não formam um triângulo!");
            }
            else
            {

                MessageBox.Show("Valores inválidos!");
                txtA.Focus();
            }
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if ((txtA.Text == "") && (txtB.Text == "") && (txtC.Text == ""))
                this.Close();
            else
            {

                if (!Double.TryParse(txtA.Text, out ladoA))
                {
                    MessageBox.Show("Valor do lado A é inválido!");
                    txtA.Text = "";
                    txtA.Focus();
                }
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if ((txtA.Text == "") && (txtB.Text == "") && (txtC.Text == ""))
                this.Close();
            else
            {

                if (!Double.TryParse(txtB.Text, out ladoB))
                {
                    MessageBox.Show("Valor do lado B é inválido!");
                    txtB.Text = "";
                    txtB.Focus();
                }
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if ((txtA.Text == "") && (txtB.Text == "") && (txtC.Text == ""))
                this.Close();
            else
            {

                if (!Double.TryParse(txtC.Text, out ladoC))
                {
                    MessageBox.Show("Valor do lado C é inválido!");
                    txtC.Text = "";
                    txtC.Focus();
                }
            }
        }
    }
}
