﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract class Empregado
    {
        private int matricula;
        private string nome;
        private DateTime data;

        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return data; }
            set { data = value; }
        }

        public abstract double SalBruto();

        public virtual int TempoTrabalho()
        {
            TimeSpan ts = DateTime.Today.Subtract(DataEntradaEmpresa);
            return ts.Days;
        }


    }
}
