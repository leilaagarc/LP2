﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativ9
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[20];
            string auxiliar;

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 20; nota++)
                {
                    auxiliar = Interaction.InputBox("Digite a " + (nota + 1) + "° nota do " + (aluno + 1) + "° aluno", "Entrada de Dados");
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Número Inválido!!!");
                        aluno--;
                        nota--;
                    }
                }
            }

            auxiliar = "";

            for (int aluno = 0; aluno < 20; aluno++)
            {
                media[aluno] = (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;
            }
            int i = 1;

            int posicao = 1;

            foreach (double elemento in media)
            {
                if (elemento != 0)
                    auxiliar += "Média do " + posicao + "° aluno: " + elemento.ToString("N1") + "\n";

                while ( i < 20)
                {
                    posicao = i + 1;
                    i++;
                    break;
                }
            }

            MessageBox.Show(auxiliar);
        }
    } 
}

