﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativ9
{
    public partial class frmExercicio6 : Form
    {
        public frmExercicio6()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[3];
            string auxiliar, branco;
            int[] pessoas = new int[3];
            int total;

            for (int j = 0; j < nomes.Length; j++)
            {
                auxiliar = Interaction.InputBox("Digite o " + (j + 1) + "° nome: ", "Entrada de Dados");
                nomes[j] = auxiliar;
                branco = auxiliar.Replace(" ", string.Empty);
                total = branco.Length;
                pessoas[j] = total;
            }

            for (int j = 0; j < 3; j++)
                listTexto.Items.Add("O nome " + nomes[j] + " possui " + pessoas[j] + " caracteres");
        }
    }
}
