﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ativ9
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int[] quantidade = new int[10];
            double[] preco = new double[10];
            double faturamentoMensal = 0;
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                while (true)
                {
                    auxiliar = Interaction.InputBox("Quantidade da " + (i + 1) + "° mercadoria", "Entrada de Dados");

                    if (quantidade[i] < 0)
                    {
                        MessageBox.Show("Quantidade não pode ser negativa!");
                    }

                    else if (!int.TryParse(auxiliar, out quantidade[i]))
                    {
                        MessageBox.Show("Não é um número!");
                    }
                    
                    else
                    {
                        break;
                    }
                }

                while (true)
                {
                    auxiliar = Interaction.InputBox("Preço da " + (i + 1) + "° mercadoria", "Preço");

                    if (preco[i] < 0)
                    {
                        MessageBox.Show("Preço não pode ser negativo!");
                    }

                    else if (!double.TryParse(auxiliar, out preco[i]))
                    {
                        MessageBox.Show("Não é um número!");
                    }

                    else
                    {
                        break;
                    }
                }

                faturamentoMensal += quantidade[i] * preco[i];

            }

            MessageBox.Show("O faturamento mensal do armazém foi de: " + faturamentoMensal.ToString("C2"));
        }
    }
    
}
