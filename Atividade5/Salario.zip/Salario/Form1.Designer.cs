﻿
namespace Salario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ckbCasado = new System.Windows.Forms.CheckBox();
            this.grbSexo = new System.Windows.Forms.GroupBox();
            this.rdbMasc = new System.Windows.Forms.RadioButton();
            this.rdbFem = new System.Windows.Forms.RadioButton();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblBruto = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtALiqIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtBruto = new System.Windows.Forms.TextBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.grbCivil = new System.Windows.Forms.GroupBox();
            this.cbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.grbSexo.SuspendLayout();
            this.grbCivil.SuspendLayout();
            this.SuspendLayout();
            // 
            // ckbCasado
            // 
            this.ckbCasado.AutoSize = true;
            this.ckbCasado.BackColor = System.Drawing.Color.Transparent;
            this.ckbCasado.Location = new System.Drawing.Point(13, 41);
            this.ckbCasado.Name = "ckbCasado";
            this.ckbCasado.Size = new System.Drawing.Size(62, 17);
            this.ckbCasado.TabIndex = 0;
            this.ckbCasado.Text = "Casado";
            this.ckbCasado.UseVisualStyleBackColor = false;
            // 
            // grbSexo
            // 
            this.grbSexo.BackColor = System.Drawing.Color.Transparent;
            this.grbSexo.BackgroundImage = global::Salario.Properties.Resources.Cores_pastéis;
            this.grbSexo.Controls.Add(this.rdbMasc);
            this.grbSexo.Controls.Add(this.rdbFem);
            this.grbSexo.Location = new System.Drawing.Point(478, 27);
            this.grbSexo.Name = "grbSexo";
            this.grbSexo.Size = new System.Drawing.Size(137, 102);
            this.grbSexo.TabIndex = 1;
            this.grbSexo.TabStop = false;
            this.grbSexo.Text = "Sexo";
            // 
            // rdbMasc
            // 
            this.rdbMasc.AutoSize = true;
            this.rdbMasc.Location = new System.Drawing.Point(19, 61);
            this.rdbMasc.Name = "rdbMasc";
            this.rdbMasc.Size = new System.Drawing.Size(73, 17);
            this.rdbMasc.TabIndex = 1;
            this.rdbMasc.TabStop = true;
            this.rdbMasc.Text = "Masculino";
            this.rdbMasc.UseVisualStyleBackColor = true;
            // 
            // rdbFem
            // 
            this.rdbFem.AutoSize = true;
            this.rdbFem.Location = new System.Drawing.Point(19, 31);
            this.rdbFem.Name = "rdbFem";
            this.rdbFem.Size = new System.Drawing.Size(67, 17);
            this.rdbFem.TabIndex = 0;
            this.rdbFem.TabStop = true;
            this.rdbFem.Text = "Feminino";
            this.rdbFem.UseVisualStyleBackColor = true;
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(586, 334);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(101, 41);
            this.btnVerificar.TabIndex = 2;
            this.btnVerificar.Text = "Verificar dados";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.Transparent;
            this.lblNome.Location = new System.Drawing.Point(74, 60);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(108, 13);
            this.lblNome.TabIndex = 3;
            this.lblNome.Text = "Nome do funcionário:";
            // 
            // lblBruto
            // 
            this.lblBruto.AutoSize = true;
            this.lblBruto.BackColor = System.Drawing.Color.Transparent;
            this.lblBruto.Location = new System.Drawing.Point(96, 88);
            this.lblBruto.Name = "lblBruto";
            this.lblBruto.Size = new System.Drawing.Size(86, 13);
            this.lblBruto.TabIndex = 4;
            this.lblBruto.Text = "Salário bruto: R$";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.BackColor = System.Drawing.Color.Transparent;
            this.lblFilhos.Location = new System.Drawing.Point(93, 117);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblFilhos.TabIndex = 5;
            this.lblFilhos.Text = "Número de filhos:";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.BackColor = System.Drawing.Color.Transparent;
            this.lblAliqINSS.Location = new System.Drawing.Point(49, 282);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(78, 13);
            this.lblAliqINSS.TabIndex = 6;
            this.lblAliqINSS.Text = "Alíquota INSS:";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.BackColor = System.Drawing.Color.Transparent;
            this.lblAliqIRPF.Location = new System.Drawing.Point(49, 316);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(77, 13);
            this.lblAliqIRPF.TabIndex = 7;
            this.lblAliqIRPF.Text = "Alíquota IRPF:";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.BackColor = System.Drawing.Color.Transparent;
            this.lblDescINSS.Location = new System.Drawing.Point(283, 282);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(101, 13);
            this.lblDescINSS.TabIndex = 8;
            this.lblDescINSS.Text = "Desconto INSS: R$";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.BackColor = System.Drawing.Color.Transparent;
            this.lblDescIRPF.Location = new System.Drawing.Point(284, 316);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(100, 13);
            this.lblDescIRPF.TabIndex = 9;
            this.lblDescIRPF.Text = "Desconto IRPF: R$";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.BackColor = System.Drawing.Color.Transparent;
            this.lblSalFamilia.Location = new System.Drawing.Point(34, 348);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(93, 13);
            this.lblSalFamilia.TabIndex = 10;
            this.lblSalFamilia.Text = "Sálario família: R$";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.BackColor = System.Drawing.Color.Transparent;
            this.lblSalLiquido.Location = new System.Drawing.Point(284, 348);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(94, 13);
            this.lblSalLiquido.TabIndex = 11;
            this.lblSalLiquido.Text = "Salário líquido: R$";
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(133, 275);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(127, 20);
            this.txtAliqINSS.TabIndex = 12;
            // 
            // txtALiqIRPF
            // 
            this.txtALiqIRPF.Enabled = false;
            this.txtALiqIRPF.Location = new System.Drawing.Point(133, 309);
            this.txtALiqIRPF.Name = "txtALiqIRPF";
            this.txtALiqIRPF.Size = new System.Drawing.Size(127, 20);
            this.txtALiqIRPF.TabIndex = 13;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(384, 275);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(127, 20);
            this.txtDescINSS.TabIndex = 14;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(384, 309);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(127, 20);
            this.txtDescIRPF.TabIndex = 15;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(133, 341);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(127, 20);
            this.txtSalFamilia.TabIndex = 16;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(384, 341);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(127, 20);
            this.txtSalLiquido.TabIndex = 17;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(188, 53);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(244, 20);
            this.txtNome.TabIndex = 18;
            // 
            // txtBruto
            // 
            this.txtBruto.Location = new System.Drawing.Point(188, 85);
            this.txtBruto.Name = "txtBruto";
            this.txtBruto.Size = new System.Drawing.Size(244, 20);
            this.txtBruto.TabIndex = 19;
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(623, 287);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(64, 34);
            this.btnSair.TabIndex = 21;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // grbCivil
            // 
            this.grbCivil.BackColor = System.Drawing.SystemColors.Control;
            this.grbCivil.BackgroundImage = global::Salario.Properties.Resources.Cores_pastéis;
            this.grbCivil.Controls.Add(this.ckbCasado);
            this.grbCivil.Location = new System.Drawing.Point(479, 135);
            this.grbCivil.Name = "grbCivil";
            this.grbCivil.Size = new System.Drawing.Size(119, 83);
            this.grbCivil.TabIndex = 25;
            this.grbCivil.TabStop = false;
            this.grbCivil.Text = "Estado civil";
            // 
            // cbxNumFilhos
            // 
            this.cbxNumFilhos.FormattingEnabled = true;
            this.cbxNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cbxNumFilhos.Location = new System.Drawing.Point(188, 114);
            this.cbxNumFilhos.Name = "cbxNumFilhos";
            this.cbxNumFilhos.Size = new System.Drawing.Size(89, 21);
            this.cbxNumFilhos.TabIndex = 26;
            this.cbxNumFilhos.UseWaitCursor = true;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(127, 218);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(0, 13);
            this.lblDados.TabIndex = 27;
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.BackColor = System.Drawing.Color.Transparent;
            this.lblMensagem.Location = new System.Drawing.Point(74, 190);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(35, 13);
            this.lblMensagem.TabIndex = 28;
            this.lblMensagem.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Salario.Properties.Resources.Cores_pastéis;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.cbxNumFilhos);
            this.Controls.Add(this.grbCivil);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.txtBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtALiqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblBruto);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.grbSexo);
            this.Name = "Form1";
            this.Text = "Desconto Salário";
            this.grbSexo.ResumeLayout(false);
            this.grbSexo.PerformLayout();
            this.grbCivil.ResumeLayout(false);
            this.grbCivil.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox ckbCasado;
        private System.Windows.Forms.GroupBox grbSexo;
        private System.Windows.Forms.RadioButton rdbMasc;
        private System.Windows.Forms.RadioButton rdbFem;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblBruto;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtALiqIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtBruto;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.GroupBox grbCivil;
        private System.Windows.Forms.ComboBox cbxNumFilhos;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblMensagem;
    }
}

