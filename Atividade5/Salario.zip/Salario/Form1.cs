﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salario
{
    public partial class Form1 : Form
    {

        double  bruto, NumFilhos, DescINSS, DescIRPF, Salario;


        public Form1()
        {
            InitializeComponent();
        }


        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {

            double SalFamilia = 0;

            if (double.TryParse(txtBruto.Text, out bruto) && double.TryParse(cbxNumFilhos.Text, out NumFilhos))
            {
                
                    //Aliquota INSS
                    if (bruto <= 800.47)
                        txtAliqINSS.Text = "7.5%";
                        DescINSS = 0.075 * bruto;

                    if (bruto >= 800.48 && bruto <= 1050)
                        txtAliqINSS.Text = "8.65%";
                        DescINSS = 0.0865 * bruto;

                    if (bruto >= 1050.01 && bruto <= 1400.77)
                        txtAliqINSS.Text = "9%";
                        DescINSS = 0.09 * bruto;

                    if (bruto >= 1400.78 && bruto <= 2801.56)
                        txtAliqINSS.Text = "11%";
                        DescINSS = 0.11 * bruto;

                    if (bruto > 2801.56)
                        txtAliqINSS.Text = "Desconto de R$308.17 (teto)";
                        DescINSS = bruto - 308.17;

                    txtDescINSS.Text = DescINSS.ToString("N2");
            }

                //Aliquota IRPF
                {
                    if (bruto <= 1257.12)
                        txtALiqIRPF.Text = "Isento";
                        DescIRPF = 0.00;

                    if (bruto >= 1257.13 && bruto <= 2512.02)
                        txtALiqIRPF.Text = "15%";
                        DescIRPF = 0.15 * bruto;

                    if (bruto > 2512.08)
                        txtALiqIRPF.Text = "27.5%";
                        DescIRPF = 0.275 * bruto;

                    txtDescIRPF.Text = DescIRPF.ToString("N2");
                }

                // Salario familia
                {
                cbxNumFilhos.Text = NumFilhos.ToString();
                    if (bruto <= 435.52)
                        SalFamilia = 22.33 * NumFilhos;
                    if (bruto >= 435.53 && bruto <= 654.61)
                        SalFamilia = 15.74 * NumFilhos;
                    if (bruto > 654.61)
                        SalFamilia = 0.00;
                    txtSalFamilia.Text = SalFamilia.ToString("N2");
                }


                // salario liquido

                    Salario = bruto - DescINSS - DescIRPF + SalFamilia;
                    txtSalLiquido.Text = Salario.ToString("N2");
                
                //Mensagem

                    lblMensagem.Visible = true;
                    lblMensagem.Text = "Os descontos do salário";

                if (rdbFem.Checked)
                    lblMensagem.Text = lblMensagem.Text + " da Sra " + txtNome.Text + ".";
                else
                    lblMensagem.Text = lblMensagem.Text + " do Sr " + txtNome.Text + ".";

                lblMensagem.Text = lblMensagem.Text + "\nEstado civil: ";

                if (ckbCasado.Checked)
                    lblMensagem.Text = lblMensagem.Text + " casado(a). ";
                else
                    lblMensagem.Text = lblMensagem.Text + " solteiro(a). ";

            lblMensagem.Text = lblMensagem.Text + "\nTotal de" + cbxNumFilhos.SelectedItem.ToString() + " filho(s) são: ";

        }





    }
}

