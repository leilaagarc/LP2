﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class IMC : Form

    {
        Double altura;
        Double peso;
        Double resultado;
        public static string nome;
        public IMC()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtResultado.Clear();
            txtClassificacao.Clear();
            txtGrau.Clear();

            txtAltura.Focus();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtAltura.Text, out altura) && Double.TryParse(txtPeso.Text, out peso))
            {
                resultado = peso / Math.Pow(altura, 2);
                txtResultado.Text = resultado.ToString("N1");
            } 
            else
            {
                MessageBox.Show("Valores Inválidos");
                txtAltura.Focus();
            }

            if (resultado < 18.5 )
            {
                txtClassificacao.Text = "MAGREZA".ToString();
                txtGrau.Text = "0".ToString();
            }
            else if (resultado < 24.9)
            {
                txtClassificacao.Text = "NORMAL".ToString();
                txtGrau.Text = "0".ToString();
            }
            else if (resultado < 29.9)
            {
                txtClassificacao.Text = "SOBREPESO".ToString();
                txtGrau.Text = "1".ToString();
            }
            else if (resultado < 39.9)
            {
                txtClassificacao.Text = "OBESIDADE".ToString();
                txtGrau.Text = "2".ToString();
            }
            else if (resultado <= 40)
            {
                txtClassificacao.Text = "OBESIDADE GRAVE".ToString();
                txtGrau.Text = "3".ToString();
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if ((txtAltura.Text == "") || (txtPeso.Text == ""))
                this.Close();
            else
            {

                if (!Double.TryParse(txtAltura.Text, out altura))
                {
                    MessageBox.Show("Valor da altura é inválido!");
                    txtClassificacao.Text = "";
                    txtGrau.Text = "";
                    txtResultado.Text = "";
                    txtAltura.Text = "";
                    txtAltura.Focus();
                }
                else if (altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    txtClassificacao.Text = "";
                    txtGrau.Text = "";
                    txtResultado.Text = "";
                    txtAltura.Text = "";
                    txtAltura.Focus();
                }
            }
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if ((txtAltura.Text == "") || (txtPeso.Text == ""))
                this.Close();
            else
            {

                if (!Double.TryParse(txtPeso.Text, out peso))
                {
                    MessageBox.Show("Valor do peso é inválido!");
                    txtClassificacao.Text = "";
                    txtGrau.Text = "";
                    txtResultado.Text = "";
                    txtPeso.Text = "";
                    txtPeso.Focus();
                }
                else if (peso <= 0)
                {
                    MessageBox.Show("Peso deve ser maior que zero!");
                    txtClassificacao.Text = "";
                    txtGrau.Text = "";
                    txtResultado.Text = "";
                    txtPeso.Text = "";
                    txtPeso.Focus();
                }
            }
        }
    }
}
