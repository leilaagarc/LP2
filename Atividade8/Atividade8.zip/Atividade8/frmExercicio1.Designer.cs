﻿
namespace Atividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTexto = new System.Windows.Forms.RichTextBox();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnRepetidas = new System.Windows.Forms.Button();
            this.lblTexto1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtTexto
            // 
            this.txtTexto.BackColor = System.Drawing.SystemColors.Info;
            this.txtTexto.Location = new System.Drawing.Point(201, 70);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(212, 173);
            this.txtTexto.TabIndex = 0;
            this.txtTexto.Text = "";
            // 
            // btnBranco
            // 
            this.btnBranco.BackColor = System.Drawing.Color.Teal;
            this.btnBranco.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBranco.ForeColor = System.Drawing.SystemColors.Control;
            this.btnBranco.Location = new System.Drawing.Point(447, 70);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(222, 39);
            this.btnBranco.TabIndex = 1;
            this.btnBranco.Text = "Número de espaços em branco";
            this.btnBranco.UseVisualStyleBackColor = false;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.BackColor = System.Drawing.Color.Teal;
            this.btnLetraR.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetraR.ForeColor = System.Drawing.SystemColors.Control;
            this.btnLetraR.Location = new System.Drawing.Point(447, 125);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(222, 49);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Número de vezes que aparece a letra “R”";
            this.btnLetraR.UseVisualStyleBackColor = false;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnRepetidas
            // 
            this.btnRepetidas.BackColor = System.Drawing.Color.Teal;
            this.btnRepetidas.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRepetidas.ForeColor = System.Drawing.SystemColors.Control;
            this.btnRepetidas.Location = new System.Drawing.Point(447, 189);
            this.btnRepetidas.Name = "btnRepetidas";
            this.btnRepetidas.Size = new System.Drawing.Size(222, 54);
            this.btnRepetidas.TabIndex = 3;
            this.btnRepetidas.Text = " Número de vezes que ocorre um mesmo par de letras na frase";
            this.btnRepetidas.UseVisualStyleBackColor = false;
            this.btnRepetidas.Click += new System.EventHandler(this.btnRepetidas_Click);
            // 
            // lblTexto1
            // 
            this.lblTexto1.AutoSize = true;
            this.lblTexto1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto1.ForeColor = System.Drawing.SystemColors.Control;
            this.lblTexto1.Location = new System.Drawing.Point(201, 40);
            this.lblTexto1.Name = "lblTexto1";
            this.lblTexto1.Size = new System.Drawing.Size(76, 19);
            this.lblTexto1.TabIndex = 4;
            this.lblTexto1.Text = "Digite aqui:";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(800, 309);
            this.Controls.Add(this.lblTexto1);
            this.Controls.Add(this.btnRepetidas);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.txtTexto);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox txtTexto;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnRepetidas;
        private System.Windows.Forms.Label lblTexto1;
    }
}