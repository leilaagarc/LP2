﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int N;
            if ((txtNumero1.Text == string.Empty) || (!int.TryParse(txtNumero1.Text, out N)))
            {
                MessageBox.Show("Valor inválido ou campo em branco!");
                txtNumero1.Clear();
                txtNumero2.Clear();
                txtNumero1.Focus();
            }

            else
            {
                int i;
                double H = 0;
                N = int.Parse(txtNumero1.Text);

                for (i = 1; i <= N; i++)
                {
                    H += 1 / (double)i;
                }

                txtNumero2.Text =  H.ToString("N2");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtNumero1.Focus();
        }
    }
}
