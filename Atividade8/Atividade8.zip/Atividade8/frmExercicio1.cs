﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            int total = 0;

            while (i < txtTexto.Text.Length)
            {
                if (char.IsWhiteSpace(txtTexto.Text[i]))
                {
                    total++;
                }
                i++;
            }

            MessageBox.Show("Há na frase " + total + " espaços brancos.");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int total = 0;

            foreach (char c in txtTexto.Text)
            {
                if (c == 'R' || c == 'r')
                    total++;
            }
            MessageBox.Show("Aparece a letra R  na frase " + total + " vezes.");
        }

        private void btnRepetidas_Click(object sender, EventArgs e)
        {
            int i, total = 0;

            for (i = 1; i < txtTexto.Text.Length; i++)
            {
                if (txtTexto.Text[i] == txtTexto.Text[i - 1])
                {
                    total++;
                }
            }

            MessageBox.Show("Aparece um par de letras na frase " + total + " vezes.");
        }
    }
    
    
    
}
