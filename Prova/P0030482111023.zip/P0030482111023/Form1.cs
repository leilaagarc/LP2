﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;


namespace P0030482111023
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] valores = new double[3, 4];
            double[] somaMes = new double[3];
            double somaTotal = 0;
            string auxiliar = "";

            for(int x = 0; x < 3; x++)
            {
                double soma = 0;

                for (int y = 0; y < 4; y++)
                {
                    auxiliar = Interaction.InputBox( "Digite o valor referente \nMês: " + (x + 1).ToString() + 
                        " \nSemana: " + (y + 1).ToString(),"Entrada de dados");

                    if (double.TryParse(auxiliar, out valores[x, y]))
                    {

                        valores[x, y] = Convert.ToDouble(auxiliar);
                        somaTotal += valores[x, y];
                        soma += valores[x, y];

                        listTexto.Items.Add(" Total do mês: " + ( x + 1).ToString() + " " +
                            "Semana: " + (y + 1) + (" ") + (String.Format("{0:C2}", valores[x, y])));

                    }
                    else
                    {
                        MessageBox.Show("Não é um valor válido!");
                        y--;
                    }


                }

                somaMes[x] = soma;

                listTexto.Items.Add(" \n>> Total Mês:" + (String.Format("{0:C2}\n", somaMes[x])));
                listTexto.Items.Add(" -----------------------------------");

            }

            listTexto.Items.Add(" -----------------------------------\n");
            listTexto.Items.Add(" Total Geral: " + (String.Format("{0:C2}", somaTotal)));
        }
    }
}
